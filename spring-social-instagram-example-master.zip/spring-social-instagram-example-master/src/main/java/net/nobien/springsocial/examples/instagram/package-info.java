/**
 * Contains @Controllers that demonstrate quick-start application functionality.
 */
package net.nobien.springsocial.examples.instagram;
