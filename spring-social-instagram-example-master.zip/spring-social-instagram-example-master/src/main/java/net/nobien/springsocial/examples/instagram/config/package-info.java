/**
 * Configures the quickstart application.
 */
package net.nobien.springsocial.examples.instagram.config;
