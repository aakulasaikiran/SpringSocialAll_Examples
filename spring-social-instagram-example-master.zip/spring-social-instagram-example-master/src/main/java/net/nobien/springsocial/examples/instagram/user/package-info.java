/**
 * A simple user authentication model supporting the quickstart application.
 */
package net.nobien.springsocial.examples.instagram.user;
